const Koa = require("koa");
const koa_router = require("koa-router");
const path = require("path");
const render = require("koa-ejs");

const app = new Koa();
const router = new koa_router();

render(app, {
    root: path.join(__dirname, "frontend"),
    layout: "layout",
    viewExt: "html",
    cache: false,
    debug: false
});

router.get('/', async ctx => {
    await ctx.render('index');
});

router.get('/inventory', async ctx => {
    await ctx.render('inventory');
});

router.get('/items', async ctx => {
    await ctx.render('items');
});

router.get('/promotions', async ctx => {
    await ctx.render('promotions');
});

router.get('/login', async ctx => {
    await ctx.render('login');
});

async function index(ctx){
    await ctx.render('/');
}

async function navInventory(ctx){
    await ctx.render('inventory');
}

async function navItems(ctx){
    await ctx.render('items');
}

async function navPromo(ctx){
    await ctx.render('promotions');
}

async function Login(ctx){
    await ctx.render('login');
}

app.use(router.routes()).use(router.allowedMethods());
app.listen(8080);